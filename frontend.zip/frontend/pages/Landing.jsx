import React from 'react'

function Landing() {
  return (
    <div>
        
    </div>
  )
}

export default Landing