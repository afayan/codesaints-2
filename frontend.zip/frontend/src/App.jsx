import { useEffect, useRef, useState } from 'react'
import './App.css'
import io from "socket.io-client"
import Dashboard from '../components/Dashboard'
import Dashboard2 from '../components/Dashboard2'

const socket = io('http://localhost:9000')

function App() {

  const [recording, setRecording] = useState(false)
  const mediaRecorderRef = useRef(null)
  const [stats, setStats] = useState(null)

  useEffect(()=>{
    socket.on('data', (data)=>{
      console.log("data is",data);
      
      setStats({...data})
    })
  }, [])


  async function startrecord() {

    // const stream = await navigator.mediaDevices.getUserMedia({audio : true})

    // const mediaRecorder = new MediaRecorder(stream)
    // mediaRecorderRef.current = mediaRecorder

    // mediaRecorder.ondataavailable = async (event) => {
    //   const blob = event.data;
    
    //   const reader = new FileReader();
    //   reader.readAsDataURL(blob); 
    //   reader.onloadend = () => {
    //     const base64Audio = reader.result.split(",")[1]; 
    //     socket.emit("audio-stream", { audioData: base64Audio }); 
    //   };
    // };
    

    // mediaRecorder.start(10000)

    socket.emit("audio-stream");

    setRecording(true)
  }

  async function stoprecord() {
    // if (mediaRecorderRef.current) {
    //   mediaRecorderRef.current.stop();
    //   socket.emit("stop-recording");
    //   setRecording(false);
    // }

    // mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());

    socket.emit("stop-recording");

    setRecording(false)
  }


  return (
    <>
      {!recording ? <button onClick={()=>startrecord()}>record</button> : 
      <button onClick={()=>stoprecord()}>stop</button>  }   
      <Dashboard data = {stats}/>

      <div className="stats">
        
      </div>
    </>
  )
}

export default App
