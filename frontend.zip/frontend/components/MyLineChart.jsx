import React, { useEffect, useState } from "react";
import { LineChart } from "@mui/x-charts";
import { Container, Typography } from "@mui/material";

function MyLineChart({data}) {

  const [seriesData, setSData] = useState([])
  const [xAxisdata, setXdata] = useState([])

  useEffect(()=>{

    //set x and y data here

  }, [data])


  return (

    <div>
    <Container>
      <Typography variant="h6" gutterBottom>
        Sample Line Chart
      </Typography>
      <LineChart
        series={[{ data: [9, 0, 10, 11, 12] }]}
        xAxis={[{ data: [0, 1, 2, 3, 4, 5, 6] }]}
        width={500}
        height={300}
      />
    </Container>
    </div>


  );
};

export default MyLineChart;
